package edu.pizza.Interfaces;

public interface IPreparable {
    void prepare();

}
